from cal_f1 import add
from cal_f2 import subtract
from cal_f3 import multiply
from cal_f4 import divide
def main():
    while True:
        try:
            num1 = float(input("Enter the first number: "))
            operator = input("Enter an operator (+, -, *, /): ")
            num2 = float(input("Enter the second number: "))


            if operator == '+':
                result = add(num1, num2)
            elif operator == '-':
                result = subtract(num1, num2)
            elif operator == '*':
                result = multiply(num1, num2)
            elif operator == '/':
                result = divide(num1, num2)
            else:
                print("Invalid operator. Please try again.")
                continue

            print(f"The result is: {result}")
        except ValueError:
            print("Invalid input. Please enter numeric values.")

        quit = input("Do you want to quit? (Y for quit, N for not): ")
        if quit.upper() == 'Y':
            break


if __name__ == "__main__":
    main()
