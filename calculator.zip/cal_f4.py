
def divide(num1, num2):
  if num2 == 0:
    raise ZeroDivisionError("Cannot divide by zero")
  return num1 / num2
